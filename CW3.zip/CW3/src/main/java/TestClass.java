public class TestClass {
    public static Integer getInt() {
        return 2;
    }

    public static Integer getDif(Integer a, Integer b) {
        return a - b;
    }

    static int getSum(int a, int b, int c) {
        return a + b + c;
    }
}
