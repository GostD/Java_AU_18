import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.Socket;

public class RmiClientServiceImpl implements RmiClientService {
    public Object invokeStatic(Class<?> clazz, Method method, Object... params) {
        Object res = null;
        try {
            Socket sc = new Socket("localhost", 8081);
            ObjectOutputStream os = new ObjectOutputStream(sc.getOutputStream());
            os.writeByte(1);
            os.writeUTF(clazz.getCanonicalName());
            os.writeUTF(method.getName());
            if (params.length > 0) {
                os.writeInt(params.length);
                for (Object obj : params) {
                    os.writeObject(obj);
                }
                os.flush();
            } else {
                os.writeInt(0);
            }
            os.flush();
            ObjectInputStream is = new ObjectInputStream(sc.getInputStream());
            res = is.readObject();
            os.close();
            is.close();
            sc.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return res;
    }

    public void init(Object localReceiverReference, Constructor constructor, Object... params) {
        try (Socket sc = new Socket("localhost", 8081)) {
            ObjectOutputStream os = new ObjectOutputStream(sc.getOutputStream());
            os.writeByte(2);
            os.writeInt(System.identityHashCode(localReceiverReference));
            os.writeUTF(constructor.getClass().getCanonicalName());
            os.writeInt(params.length);
            for (int i = 0; i < params.length; i++) {
                os.writeObject(params[i]);
            }
            os.flush();

            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object invokeOn(Object localReceiverReference, Method method, Object... params) {
        Object res = null;
        try (Socket sc = new Socket("localhost", 8081)) {

            ObjectOutputStream os = new ObjectOutputStream(sc.getOutputStream());
            os.writeByte(3);
            os.writeInt(System.identityHashCode(localReceiverReference));
            os.writeUTF(method.getClass().getCanonicalName());
            os.writeUTF(method.getName());
            os.writeInt(params.length);
            for (int i = 0; i < params.length; i++) {
                os.writeObject(params[i]);
            }
            os.flush();
            ObjectInputStream is = new ObjectInputStream(sc.getInputStream());
            res = is.readObject();
            is.close();
            os.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return res;
    }

    public void test() throws NoSuchMethodException, InterruptedException {
        RmiServerService ss = new RmiServerServiceImpl();
        Thread th = new Thread(() -> ss.launch("8081"));
        th.start();
//        Method met = TestClass.class.getMethod("getDif", Integer.class, Integer.class);
//        Integer res = (Integer)invokeStatic(TestClass.class, met, 9, 2);


//        Method met = TestClass.class.getMethod("getInt");
//        Integer res = (Integer)invokeStatic(TestClass.class, met);

//        System.out.println(res);

//        init(new Object(), Integer.class.getDeclaredConstructor(int.class), 2);
        th.join();
    }

    public static void main(String[] args) throws NoSuchMethodException, InterruptedException {
        new RmiClientServiceImpl().test();
    }
}
