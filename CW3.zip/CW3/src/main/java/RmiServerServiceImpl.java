import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class RmiServerServiceImpl implements RmiServerService {
    private Map<Integer, Object> map;
    public RmiServerServiceImpl() {
        map = new HashMap<>();
    }
    public void launch(String port) {
        while (true) {
            ServerSocket servSc = null;
            Socket sc = null;
            try {
                servSc = new ServerSocket(Short.parseShort(port));
                sc = servSc.accept();
                ObjectInputStream is = new ObjectInputStream(sc.getInputStream());
                byte bt = is.readByte();
                if (bt == 1) {
                    String clsCanonicalName = is.readUTF();
                    String methodName = is.readUTF();
                    int count = is.readInt();
                    Object[] objs = new Object[count];
                    Class[] objsCls = new Class[count];
                    for (int i = 0; i < count; i++) {
                        objs[i] = is.readObject();
                        objsCls[i] = objs[i].getClass();
                    }
                    Class<?> cls = Class.forName(clsCanonicalName);
                    Method met = cls.getDeclaredMethod(methodName, objsCls);
                    Object res = met.invoke(cls, objs);
                    ObjectOutputStream os = new ObjectOutputStream(sc.getOutputStream());
                    os.writeObject(res);
                    os.flush();
                    os.close();
                    is.close();
                } else if (bt == 2) {
                    int localRef = is.readInt();
                    Class<?> cls = Class.forName(is.readUTF());
                    int count = is.readInt();
                    Object[] objs = new Object[count];
                    Class[] clsOb = new Class[count];
                    for (int i = 0; i < count; i++) {
                        objs[i] = is.readObject();
                        clsOb[i] = objs[i].getClass();
                    }
                    Constructor cst = cls.getDeclaredConstructor(clsOb);
                    Object ob = cst.newInstance(objs);
                    map.put(localRef, ob);
                } else if (bt == 3) {
                    int localRef = is.readInt();
                    Class<?> cls = Class.forName(is.readUTF());
                    String metName = is.readUTF();
                    int count = is.readInt();
                    Object[] objs = new Object[count];
                    Class[] objsCls = new Class[count];
                    for (int i = 0; i < count; i++) {
                        objs[i] = is.readObject();
                        objsCls[i] = objs[i].getClass();
                    }
                    Method met = cls.getDeclaredMethod(metName, objsCls);
                    Object res = met.invoke(map.get(localRef), objs);
                    ObjectOutputStream os = new ObjectOutputStream(sc.getOutputStream());
                    os.writeObject(res);
                    os.flush();
                    os.close();
                    is.close();
                }
            } catch (IOException | ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e) {
                e.printStackTrace();
            } finally {
                try {
                if (sc != null) sc.close();
                if (servSc != null) servSc.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
