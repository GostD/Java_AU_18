package ru.spbau.mit.aunit;

public class MyException extends Throwable {}
