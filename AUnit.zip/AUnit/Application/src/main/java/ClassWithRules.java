import ru.spbau.mit.aunit.*;

import java.util.concurrent.Callable;

import static ru.spbau.mit.StaticLog.log;

public class ClassWithRules {
    private int counter;

    public ClassWithRules() {
        log = new StringBuilder();
    }

    @Rule
    public TestRule myTestRule1 = new MyTestRule("Inner rule");

    @Rule
    public MyTestRule myTestRule2 = new MyTestRule("Outer rule");

    @BeforeEach
    public void before() {
        log.append("Before, ").append(++counter).append("\n");
    }

    @AfterEach
    public void after() {
        log.append("After, ").append(++counter).append("\n");
    }


    @Test
    public void okTest() {
        log.append("Executing test\n");
    }

    @Test(expected = RuntimeException.class)
    public void expectException() {
        log.append("Executing test\n");
        throw new RuntimeException();
    }

    @Test
    public void fail() {
        log.append("Executing test\n");
        throw new RuntimeException();
    }

    @Test
    @Ignore(reason = "ignore")
    public void ignored() {
        log.append("Ignored test shoudln't be invoked!\n");
    }

    public class MyTestRule implements TestRule {
        private final String name;

        public MyTestRule(String name) {
            this.name = name;
        }

        @Override
        public Callable<Void> apply(Callable<Void> testExecutor) {
            log.append(name).append(" apply, ").append(++counter).append("\n");
            return () -> {
                log.append(name).append(" before wrapper, ").append(++counter).append("\n");

                testExecutor.call();

                log.append(name).append(" after wrapper, ").append(++counter).append("\n");
                return null;
            };
        }
    }
}
