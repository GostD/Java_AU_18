import ru.spbau.mit.aunit.Ignore;
import ru.spbau.mit.aunit.Test;

public class SimpleClass {
    @Test
    public void okTest() { }

    @Test
    public void failTestWithoutExpectedException() {
        int x = (Integer) null;
    }

    @Ignore
    @Test
    public void ignoreTestNoReason() {
        throw new RuntimeException("");
    }

    @Ignore(reason = "reason")
    @Test
    public void ignoreTestWithReason() {
        throw new RuntimeException("");
    }

    @Test(expected = MyException.class)
    public void testWithExpectedException() throws Exception {
        throw new MyException();
    }

    public static class MyException extends Exception { }
}
