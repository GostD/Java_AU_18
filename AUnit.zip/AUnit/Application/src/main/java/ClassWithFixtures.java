import ru.spbau.mit.aunit.*;

import static ru.spbau.mit.StaticLog.log;

public class ClassWithFixtures {
    private int counter = 0;

    public ClassWithFixtures() {
        log = new StringBuilder();
    }

    @SetUp
    public void setUp() {
        log.append("Set up\n");
    }

    @TearDown
    public void tearDown() {
        log.append("Tear down\n");
    }

    @BeforeEach
    public void beforeTest() {
        log.append("Before ").append(++counter).append("\n");
    }

    @AfterEach
    public void afterTest() {
        log.append("After ").append(counter).append("\n");
    }

    @Test
    public String okTest() {
        log.append("Executing test\n");
        return "ok";
    }

    @Ignore
    @Test
    public String ignoredTest() {
        log.append("IGNORED TEST\n");
        throw new RuntimeException();
    }

    @Test(expected = RuntimeException.class)
    public void failWithExpected() {
        log.append("Executing test\n");
        throw new RuntimeException();
    }

    @Test
    public void failWithoutExpected() {
        log.append("Executing test\n");
        throw new RuntimeException();
    }

    public String getLog() {
        return log.toString();
    }
}
