package ru.spbau.mit.model;

import java.util.concurrent.TimeUnit;

public class MyTestResult implements TestResult {

    String testClassName;
    String testMethodName;
    TestStatus status;
    long time;
    Throwable result;
    String ignoreReason;

    public MyTestResult(String testClassName,
                        String testMethodName,
                        TestStatus status,
                        long time,
                        Throwable result,
                        String ignoreReason) {
        this.testClassName = testClassName;
        this.testMethodName = testMethodName;
        this.status = status;
        this.time = time;
        this.result = result;
        this.ignoreReason = ignoreReason;
    }

    @Override
    public String getTestCaseName() {
        return testClassName;
    }

    @Override
    public String getTestName() {
        return testMethodName;
    }

    @Override
    public TestStatus getTestStatus() {
        return status;
    }

    @Override
    public long getTime(TimeUnit unit) {
        return time;
    }

    @Override
    public Throwable getThrowable() {
        return result;
    }

    @Override
    public String getIgnoreReason() {
        return ignoreReason;
    }
}
