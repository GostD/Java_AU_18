package ru.spbau.mit.model;

import java.util.Collection;

public interface TestRunner {
    /**
     *
     * @param root - относительный путь до папки с .class-файлами
     * @param classNames - классы, тесты из которых необходимо запустить.
     *                   Гарантируется, что для каждого name из classNames существует соответствующий файл 'root/name.class'
     *
     * @throws TestExecutionException - можете оборачивать в него и бросать всякие исключение, летящие из JDK
     */
    Collection<TestResult> runTests(String root, String[] classNames) throws TestExecutionException;

}
