package ru.spbau.mit.model;

import java.util.concurrent.TimeUnit;

public interface TestResult {
    /**
     * Имя класса с тестом
     */
    String getTestCaseName();

    /**
     * Имя метода, проаннотированного @Test
     */
    String getTestName();

    /**
     * Объект {@link TestStatus}, соответствующий статусу выполнения этого теста
     */
    TestStatus getTestStatus();

    /**
     * Возвращает время выполнения теста в единицах измерения {@param unit}
     */
    long getTime(TimeUnit unit);

    /**
     * Возвращает исключение, с которым завершилось исполнение теста, или {@code null}
     */
    Throwable getThrowable();

    /**
     * Если данный тест был помечен аннотацией {@link ru.spbau.mit.aunit.Ignore}, то
     * возвращается значение поля {@link ru.spbau.mit.aunit.Ignore#reason}.
     *
     * В противном случае, возвращается {@code null}
     */
    String getIgnoreReason();
}
