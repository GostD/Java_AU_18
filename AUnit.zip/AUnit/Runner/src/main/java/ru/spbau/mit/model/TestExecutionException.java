package ru.spbau.mit.model;

public class TestExecutionException extends Exception {
    public TestExecutionException() {
        super();
    }

    public TestExecutionException(String message) {
        super(message);
    }

    public TestExecutionException(String message, Throwable cause) {
        super(message, cause);
    }

    public TestExecutionException(Throwable cause) {
        super(cause);
    }

    protected TestExecutionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
