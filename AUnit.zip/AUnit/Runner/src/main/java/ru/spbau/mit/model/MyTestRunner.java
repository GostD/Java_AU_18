package ru.spbau.mit.model;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import ru.spbau.mit.aunit.*;

public class MyTestRunner implements TestRunner {

    @Override
    public Collection<TestResult> runTests(String root, String[] classNames) throws TestExecutionException {
        Class[] classes = new Class[classNames.length];
        Collection<TestResult> result = new ArrayList<>();
        try {
            URL dir = Paths.get(root).toUri().toURL();
            ClassLoader cl = new URLClassLoader(new URL[]{dir});
            for (int i = 0; i < classNames.length; i++) {
                classes[i] = cl.loadClass(classNames[i]);
            }
        } catch (MalformedURLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        for (Class<?> cls : classes) {
            Method[] methods = cls.getDeclaredMethods();
            try {
                Object obj = cls.newInstance();

                List<Method> setUp = new ArrayList<>();
                List<Method> tearDown = new ArrayList<>();
                List<Method> beforeEach = new ArrayList<>();
                List<Method> afterEach = new ArrayList<>();

                for (Method met : methods) {
                    if (met.getAnnotation(Ignore.class) == null) {
                        if (met.getAnnotation(SetUp.class) != null) {
                            setUp.add(met);
                        }
                        if (met.getAnnotation(TearDown.class) != null) {
                            tearDown.add(met);
                        }
                        if (met.getAnnotation(BeforeEach.class) != null) {
                            beforeEach.add(met);
                        }
                        if (met.getAnnotation(AfterEach.class) != null) {
                            afterEach.add(met);
                        }
                    }
                }
                for (Method met : setUp) {
                    met.invoke(obj);
                }

                for (Method met : methods) {
                    Test tst = met.getAnnotation(Test.class);
                    if (tst != null) {
                        Ignore ign = met.getAnnotation(Ignore.class);
                        if (ign != null) {
                            result.add(new MyTestResult(cls.getName(), met.getName(), TestStatus.IGNORED, 0, null, ign.reason()));
                        }
                        else {
                                for (Method meth : beforeEach) {
                                    meth.invoke(obj);
                                }
                                long start = System.nanoTime();
                                TestStatus stat = TestStatus.SUCCESS;
                                Throwable rs = null;
                                try {
                                    met.invoke(obj);
                                } catch (Throwable testRes) {
                                    rs = testRes.getCause();
                                    if (!tst.expected().isAssignableFrom(rs.getClass())) {
                                        stat = TestStatus.FAIL;
                                    }
                                }
                                long end = System.nanoTime();
                                long elapsedTime = end - start;
                                TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);

                                result.add(new MyTestResult(cls.getName(), met.getName(), stat, elapsedTime, rs, null));
                                for (Method meth : afterEach) {
                                    meth.invoke(obj);
                                }
                        }
                    }

                }
                for (Method met : tearDown) {
                    met.invoke(obj);
                }
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        return result;

    }
}
