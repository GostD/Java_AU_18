package ru.spbau.mit.model;

import ru.spbau.mit.aunit.Ignore;
import ru.spbau.mit.aunit.Test;

public enum TestStatus {
    /**
     * Тест завершился успешно, или же бросил исключение, заявленное в {@link Test#expected()}
     */
    SUCCESS,

    /**
     * Тест бросил исключение, не объявленное в {@link Test#expected()}
     */
    FAIL,

    /**
     * Тест был помечен аннотацией {@link Ignore}
     */
    IGNORED
}
