package ru.spbau.mit;

/**
 * This class is used strictly for testing. Move on, folks, nothing to see here.
 */
public class StaticLog {
    public static StringBuilder log = new StringBuilder();
}
