package ru.spbau.mit;

import org.junit.Test;
import ru.spbau.mit.utils.AbstractTest;

import static org.junit.Assert.assertEquals;

public class Task2 extends AbstractTest {

    @Test
    public void testFixtures() throws Exception {
        doTest("Fixtures", "ClassWithFixtures");
        String actualLog = StaticLog.log.toString();
        String expectedLog =
                "Set up\n" +
                "Before 1\n" +
                "Executing test\n" +
                "After 1\n" +
                "Before 2\n" +
                "Executing test\n" +
                "After 2\n" +
                "Before 3\n" +
                "Executing test\n" +
                "After 3\n" +
                "Tear down\n";
        assertEquals("Something is wrong with fixture methods calls", expectedLog, actualLog);
    }

    @Test
    public void testFixturesTwice() throws Exception {
        // Because ClassWithFixture imitates inner state via hooping around static field,
        // this test checks (well, *probably* checks) that for each test case instance is
        // correctly created and then disposed.
        testFixtures();
        testFixtures();
    }
}
