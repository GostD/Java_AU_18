package ru.spbau.mit.utils;

import ru.spbau.mit.model.MyTestRunner;
import ru.spbau.mit.model.TestRunner;

import java.util.Collections;

public class TestRunnerProvider {
    public static TestRunner getTestRunner() {

        return new MyTestRunner();//(root, classNames) -> Collections.emptyList();
    }
}
