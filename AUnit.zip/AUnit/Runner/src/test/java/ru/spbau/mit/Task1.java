package ru.spbau.mit;

import org.junit.Test;
import ru.spbau.mit.utils.AbstractTest;

import static org.junit.Assert.assertEquals;

public class Task1 extends AbstractTest {
    @Test
    public void testBasic() throws Throwable {
        doTest("SimpleTest", "SimpleClass");
    }

    @Test
    public void testMulticlassTest() throws Throwable {
        doTest("MulticlassTest", "SimpleClass", "SimulatingTests");
    }
}
