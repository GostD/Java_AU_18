package ru.spbau.mit.utils;

import ru.spbau.mit.model.TestResult;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public abstract class AbstractTest {
    private static final String pathToResources = "src/test/resources/testdata";
    protected static final String pathToFolderWithCompiledTestClasses = "../Application/out/production/classes";//"../Application/build/classes/java/main";

    protected void doTest(String testName, String... classNames) throws Exception {
        Path pathToExpectedData = Paths.get(pathToResources).resolve(testName);
        String expectedData = readExpectedData(pathToExpectedData);

        Collection<TestResult> actualTestResults = TestRunnerProvider.getTestRunner().runTests(pathToFolderWithCompiledTestClasses, classNames);
        String actualData = Utils.dumpTestResult(actualTestResults);

        if (expectedData == null) {
            try {
                Files.createFile(pathToExpectedData);
                Files.write(pathToExpectedData, actualData.getBytes());
                fail("Expected testdata for test " + testName + " was missing, generating");
            } catch (IOException e) {
                throw new RuntimeException("Uh-oh! Something went wrong in testing framework!", e);
            }
        }

        assertEquals(expectedData, actualData);
    }

    private String readExpectedData(Path pathToExpectedData) {
        if (!Files.exists(pathToExpectedData)) {
            return null;
        }

        try {
            return new String(Files.readAllBytes(pathToExpectedData));
        } catch (IOException e) {
            throw new RuntimeException("Uh-oh! Something went wrong in testing framework!", e);
        }
    }
}
