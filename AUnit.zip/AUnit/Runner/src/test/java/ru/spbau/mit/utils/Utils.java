package ru.spbau.mit.utils;

import ru.spbau.mit.model.TestResult;
import ru.spbau.mit.model.TestStatus;

import java.util.Collection;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class Utils {
    public static String dumpTestResult(Collection<TestResult> results) {
        return results.stream().sorted(Comparator.comparing(TestResult::getTestName))
                .map(Utils::renderTestResult)
                .collect(Collectors.joining("\n"));
    }

    private static String renderTestResult(TestResult tr) {
        StringBuilder sb = new StringBuilder();

        sb.append("Test case: ").append(tr.getTestCaseName()).append("\n")
                .append("Test: ").append(tr.getTestName()).append("\n")
                .append("Result ").append(tr.getTestStatus()).append("\n");

        if (tr.getTestStatus() == TestStatus.IGNORED) {
            sb.append("Ignore reason: '").append(tr.getIgnoreReason()).append("'\n");
        } else {
            if (tr.getTime(TimeUnit.NANOSECONDS) == 0) {
                sb.append("Runned for 0 nanoseconds, WTF?!\n");
            } else {
                sb.append("Runned for some time\n");
            }

            if (tr.getTestStatus() == TestStatus.FAIL) {
                sb.append("Failed with: ").append(tr.getThrowable()).append("\n");
            }
        }

        return sb.toString();
    }
}
