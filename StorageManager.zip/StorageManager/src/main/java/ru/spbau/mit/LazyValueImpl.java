package ru.spbau.mit;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;

public class LazyValueImpl<R> implements LazyValue<R> {
    private R value;
    private Lock lock = new ReentrantLock();
    private Lock calc = new ReentrantLock();
    private Condition cond = calc.newCondition();
    private RuntimeException except;
    private boolean excepted;
    private Supplier<R> supplier;
//    private boolean counted;

    public LazyValueImpl(Supplier<R> supplier) {
        value = null;
        this.supplier = supplier;
        excepted = false;
//        counted = false;
    }

    public R get() throws RecursiveComputationException, InterruptedException {
        if (excepted) throw except;
        lock.lock();
        if (excepted) throw except;
        try {
            if (!calc.tryLock()) cond.await();
            if (supplier != null) value = supplier.get();

            supplier = null;
//            counted = true;
            return value;
        } catch (RuntimeException e) {
            except = e;
            excepted = true;
            throw e;
        } finally {
            calc.unlock();
            lock.unlock();
        }
    }

    public boolean isReady() {
        lock.lock();
        try {
            return (supplier == null);
        } finally {
            lock.unlock();
        }
    }

}
