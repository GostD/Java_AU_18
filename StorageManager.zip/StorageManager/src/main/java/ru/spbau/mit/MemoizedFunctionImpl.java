package ru.spbau.mit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;

public class MemoizedFunctionImpl<T, R> implements MemoizedFunction<T, R> {

    private Function<T, R> function;
    private Map<T, R> vals = new HashMap<>();
    private Set<T> set = new HashSet<>();
    private RuntimeException except;
    private boolean excepted;

    MemoizedFunctionImpl(Function<T, R> function) {
        this.function = function;
    }
    @Override
    public R apply(T argument) throws RecursiveComputationException, InterruptedException {
        if (set.contains(argument)) argument.wait();
        if (excepted) throw except;
        synchronized (argument) {
            if (excepted) throw except;
            try {
                if (!vals.containsKey(argument)) {
                    R res = function.apply(argument);
                    vals.put(argument, res);
                }
            } catch (RuntimeException e) {
                except = e;
                excepted = true;
                throw e;
            } finally {
                set.remove(argument);
                argument.notifyAll();
            }
        }

        return vals.get(argument);
    }

    @Override
    public boolean isComputedAt(T argument) {
        synchronized (argument) {
            return vals.containsKey(argument);
        }
    }
}
