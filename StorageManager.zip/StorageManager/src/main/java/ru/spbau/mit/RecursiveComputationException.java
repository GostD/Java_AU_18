package ru.spbau.mit;

public class RecursiveComputationException extends Exception {
}
